// BaseMaker — generatore semplice di basi musicali con Tone.js
// Tutto gira nel browser. Nessun upload.

// --- riferimenti UI ---
const els = {
  genre: document.getElementById('genre'),
  key: document.getElementById('key'),
  scale: document.getElementById('scale'),
  bpm: document.getElementById('bpm'),
  bpmVal: document.getElementById('bpmVal'),
  bars: document.getElementById('bars'),
  swing: document.getElementById('swing'),
  swingVal: document.getElementById('swingVal'),
  humanize: document.getElementById('humanize'),
  generate: document.getElementById('generate'),
  randomize: document.getElementById('randomize'),
  start: document.getElementById('start'),
  stop: document.getElementById('stop'),
  export: document.getElementById('export'),
  progression: document.getElementById('progression'),
  levels: {
    drum: document.getElementById('drumLevel'),
    bass: document.getElementById('bassLevel'),
    chord: document.getElementById('chordLevel'),
    drumVal: document.getElementById('drumLevelVal'),
    bassVal: document.getElementById('bassLevelVal'),
    chordVal: document.getElementById('chordLevelVal'),
  }
};

els.bpm.addEventListener('input', ()=> els.bpmVal.textContent = els.bpm.value);
els.swing.addEventListener('input', ()=> els.swingVal.textContent = els.swing.value);
els.levels.drum.addEventListener('input', ()=> els.levels.drumVal.textContent = `${els.levels.drum.value} dB`);
els.levels.bass.addEventListener('input', ()=> els.levels.bassVal.textContent = `${els.levels.bass.value} dB`);
els.levels.chord.addEventListener('input', ()=> els.levels.chordVal.textContent = `${els.levels.chord.value} dB`);

// --- teoria musicale base ---
const NOTES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"];
const MAJOR_SCALE = [0,2,4,5,7,9,11];
const NAT_MINOR = [0,2,3,5,7,8,10];

function noteIndex(n){ return NOTES.indexOf(n); }
function mod(n,m){ return ((n % m) + m) % m; }

function buildScale(rootName, isMajor=true){
  const root = noteIndex(rootName);
  const steps = isMajor ? MAJOR_SCALE : NAT_MINOR;
  return steps.map(s=> NOTES[mod(root + s, 12)]);
}

// Mappature gradi -> triadi
const DEG_TO_TRIAD = {
  major: ["maj","min","min","maj","maj","min","dim"],
  minor: ["min","dim","maj","min","min","maj","maj"]
};

function triad(rootMidi, quality){
  // costruiamo triade in semitoni
  let intervals;
  switch(quality){
    case "maj": intervals = [0,4,7]; break;
    case "min": intervals = [0,3,7]; break;
    case "dim": intervals = [0,3,6]; break;
    default: intervals = [0,4,7];
  }
  return intervals.map(i=> rootMidi + i);
}

function midiToFreq(m){ return 440 * Math.pow(2, (m-69)/12); }
function nameToMidi(name, octave=4){
  const idx = NOTES.indexOf(name);
  return 12 * (octave + 1) + idx; // MIDI: C4=60, quindi octave=4 => 60
}

// Progressioni tipiche per genere (gradi, 1=tonica)
const PROGRESSIONS = {
  "Pop": [[1,5,6,4], [1,6,4,5], [1,5,4,4]],
  "Trap": [[1,6,3,7], [1,7,6,7], [6,5,4,3]], // in scala minore
  "R&B": [[2,5,1,6], [4,3,2,5], [6,2,5,1]],
  "Reggaeton": [[1,7,6,5], [6,5,4,3]],       // spesso minore
  "Rock": [[1,7,4,1], [1,4,5,4], [6,7,1,1]]
};

// Pattern batteria di base (16 step per battuta)
const DRUM_PATTERNS = {
  "Pop":    {kick:[0,8], snare:[4,12], hat:[0,2,4,6,8,10,12,14]},
  "Trap":   {kick:[0,8], snare:[4,12], hat:[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]},
  "R&B":    {kick:[0,8], snare:[6,14], hat:[0,2,4,6,8,10,12,14]},
  "Reggaeton": {kick:[0,8], snare:[5,13], hat:[0,2,4,6,8,10,12,14]},
  "Rock":   {kick:[0,8], snare:[4,12], hat:[0,2,4,6,8,10,12,14]}
};

let state = {
  chords: [], // array di triadi in Hz per ogni battuta
  bass: [],   // nota fondamentale per ogni battuta
  bars: 8,
  bpm: 110,
  genre: "Pop",
  key: "C",
  scale: "Maggiore"
};

function choose(arr){ return arr[Math.floor(Math.random()*arr.length)]; }

function generateProgression(){
  state.genre = els.genre.value;
  state.key = els.key.value;
  state.scale = els.scale.value;
  state.bpm = +els.bpm.value;
  state.bars = +els.bars.value;

  const isMajor = (state.scale === "Maggiore");
  const progPool = PROGRESSIONS[state.genre];
  let degrees = choose(progPool).slice();

  // Se genere tipicamente minore, forziamo minore
  if (["Trap","Reggaeton"].includes(state.genre)) {
    if (isMajor) {
      // auto-switch a minore perché più coerente
      els.scale.value = "Minore";
    }
  }

  const mode = (els.scale.value === "Maggiore") ? "major" : "minor";
  const scale = buildScale(state.key, mode==="major");
  const degToQual = DEG_TO_TRIAD[mode];

  // ripetiamo progressione per coprire tutte le battute
  const times = Math.ceil(state.bars / degrees.length);
  const fullDegrees = Array(times).fill(0).flatMap(()=> degrees).slice(0, state.bars);

  // costruisci triadi e bassi per ciascuna misura
  const chords = [];
  const bass = [];
  fullDegrees.forEach((deg, i)=>{
    const scaleIndex = ((deg-1) % 7);
    const rootName = scale[scaleIndex];
    const quality = degToQual[scaleIndex];
    // posizioniamo accordi intorno all'ottava 4
    const rootMidi = nameToMidi(rootName, 3); // triade più bassa
    const tri = triad(rootMidi, quality).map(midiToFreq);
    chords.push(tri);
    bass.push(midiToFreq(rootMidi - 12)); // basso un'ottava sotto
  });

  state.chords = chords;
  state.bass = bass;

  // UI
  els.progression.textContent = "Progressione: " + fullDegrees.map(d => roman(d, mode)).join(" – ");
}

function roman(deg, mode){
  const map = mode==="major" ? ["I","ii","iii","IV","V","vi","vii°"] : ["i","ii°","III","iv","v","VI","VII"];
  return map[(deg-1)%7];
}

// --- Sintetizzatori ---
let started = false;
let masterFilter, limiter, reverb, delay;
let drum = {}, bassSynth, chordSynth;
let recorder;

async function setupAudio(){
  await Tone.start();
  if (started) return;
  started = true;

  Tone.Transport.bpm.value = state.bpm;
  Tone.Transport.swing = (+els.swing.value)/100;
  Tone.Transport.swingSubdivision = "8n";

  // effetti/master
  reverb = new Tone.Reverb({decay: 2.8, wet: 0.2}).toDestination();
  delay = new Tone.PingPongDelay({delayTime: "8n", feedback: 0.2, wet: 0.1}).connect(reverb);
  limiter = new Tone.Limiter(-1).connect(delay);
  masterFilter = new Tone.Filter(18000, "lowpass").connect(limiter);

  // batteria sintetica
  drum.kick = new Tone.MembraneSynth({pitchDecay: 0.008, octaves: 4, envelope:{attack:0.001, decay:0.6, sustain:0}}).connect(masterFilter);
  drum.snare = new Tone.NoiseSynth({noise:{type:"white"}, envelope:{attack:0.001, decay:0.2, sustain:0}, volume: -6}).connect(masterFilter);
  drum.hat = new Tone.MetalSynth({frequency: 250, envelope:{attack:0.001, decay:0.12, release:0.01}, harmonicity:5.1, modulationIndex:32, resonance:4000}).connect(masterFilter);

  // livelli
  drum.kick.volume.value = +els.levels.drum.value;
  drum.snare.volume.value = +els.levels.drum.value - 2;
  drum.hat.volume.value = +els.levels.drum.value - 4;

  // basso e accordi
  bassSynth = new Tone.MonoSynth({
    oscillator:{type:"square"},
    filter:{type:"lowpass", rolloff:-24},
    filterEnvelope:{attack:0.01, decay:0.2, sustain:0.2, release:0.2, baseFrequency:120, octaves:2},
    envelope:{attack:0.01, decay:0.2, sustain:0.4, release:0.3}
  }).connect(masterFilter);
  bassSynth.volume.value = +els.levels.bass.value;

  chordSynth = new Tone.PolySynth(Tone.AMSynth, {
    oscillator:{type:"sine"},
    envelope:{attack:0.02, decay:0.3, sustain:0.5, release:0.8}
  }).connect(masterFilter);
  chordSynth.volume.value = +els.levels.chord.value;

  // recorder
  recorder = new Tone.Recorder();
  masterFilter.connect(recorder);
}

function schedule(){
  Tone.Transport.cancel();
  Tone.Transport.bpm.rampTo(+els.bpm.value, 0.05);
  Tone.Transport.swing = (+els.swing.value)/100;
  const human = els.humanize.checked;

  const bars = +els.bars.value;
  const stepsPerBar = 16;
  const totalSteps = bars * stepsPerBar;
  const hatPattern = DRUM_PATTERNS[state.genre].hat;
  const snarePattern = DRUM_PATTERNS[state.genre].snare;
  const kickPattern = DRUM_PATTERNS[state.genre].kick;

  // BATTERIA
  for (let bar = 0; bar < bars; bar++){
    const offset = `+${bar}m`;
    // cassa e rullante
    kickPattern.forEach(step => {
      const time = Tone.Time(offset) + Tone.Time(`${step * (1/4)/stepsPerBar}m`);
      const t = human ? (time + (Math.random()*0.02 - 0.01)) : time;
      Tone.Transport.schedule(()=> drum.kick.triggerAttackRelease("C2", "8n", undefined, 1), t);
    });
    snarePattern.forEach(step => {
      const time = Tone.Time(offset) + Tone.Time(`${step * (1/4)/stepsPerBar}m`);
      const t = human ? (time + (Math.random()*0.02 - 0.01)) : time;
      Tone.Transport.schedule(()=> drum.snare.triggerAttackRelease("8n"), t);
    });
    hatPattern.forEach(step => {
      const time = Tone.Time(offset) + Tone.Time(`${step * (1/4)/stepsPerBar}m`);
      const t = human ? (time + (Math.random()*0.015 - 0.007)) : time;
      Tone.Transport.schedule(()=> drum.hat.triggerAttackRelease("16n", undefined, 0.6), t);
    });
  }

  // BASSO & ACCORDI — 1 accordo per battuta
  for (let bar = 0; bar < bars; bar++){
    const offset = `+${bar}m`;
    const chord = state.chords[bar % state.chords.length];
    const bass = state.bass[bar % state.bass.length];

    Tone.Transport.schedule(()=> {
      // basso ogni 1/2 battuta
      bassSynth.triggerAttackRelease(bass, "2n");
      // accordo "pad" tenuto sulla battuta
      chordSynth.triggerAttackRelease(chord, "1m");
    }, offset);
  }
}

function randomizeAll(){
  const genres = Array.from(els.genre.options).map(o=>o.value);
  els.genre.value = choose(genres);
  const keys = Array.from(els.key.options).map(o=>o.value);
  els.key.value = choose(keys);
  els.scale.value = Math.random()>0.5 ? "Maggiore" : "Minore";
  els.bpm.value = Math.floor(80 + Math.random()*70);
  els.bpm.dispatchEvent(new Event('input'));
  els.swing.value = Math.floor(Math.random()*35);
  els.swing.dispatchEvent(new Event('input'));
  ['drum','bass','chord'].forEach(k=> {
    els.levels[k].value = [-6,-5,-4,-3,-2,0][Math.floor(Math.random()*6)];
    els.levels[k].dispatchEvent(new Event('input'));
  });
  generateProgression();
}

els.generate.addEventListener('click', ()=> {
  generateProgression();
  if (started) { schedule(); }
});

els.randomize.addEventListener('click', ()=> {
  randomizeAll();
  if (started) { schedule(); }
});

els.start.addEventListener('click', async ()=> {
  await setupAudio();
  if (state.chords.length===0) generateProgression();
  schedule();
  Tone.Transport.start();
});

els.stop.addEventListener('click', ()=> {
  Tone.Transport.stop();
});

els.export.addEventListener('click', async ()=> {
  await setupAudio();
  if (state.chords.length===0) generateProgression();
  schedule();

  // registra per N misure e poi ferma
  const bars = +els.bars.value;
  const seconds = (60 / (+els.bpm.value)) * 4 * bars;
  recorder.start();
  Tone.Transport.start();
  setTimeout(async ()=> {
    Tone.Transport.stop();
    const blob = await recorder.stop();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BaseMaker_${state.genre}_${state.key}${els.scale.value==='Maggiore'?'maj':'min'}_${els.bpm.value}bpm.wav`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }, (seconds+0.2)*1000);
});

// init UI
generateProgression();
